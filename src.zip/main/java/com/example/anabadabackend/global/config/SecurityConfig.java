package com.example.anabadabackend.global.config;

import com.example.anabadabackend.global.security.JwtAuthenticationFilter;
import com.example.anabadabackend.global.util.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtTokenProvider jwtTokenProvider;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // 1. CSRF 및 불필요한 기본 UI 폼 비활성화 (Stateless 토큰 기반이기 때문)
                .csrf(AbstractHttpConfigurer::disable)
                .httpBasic(AbstractHttpConfigurer::disable)
                .formLogin(AbstractHttpConfigurer::disable)

                // 2. JWT 인증을 사용하므로 세션을 메모리에 생성하지 않도록 강제 지시
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // 3. 🟢 [403 해결의 핵심] 경로를 명확하게 쪼개어 프리패스 성문을 활짝 엽니다.
                .authorizeHttpRequests(auth -> auth
                        // 이메일 인증 관련 전체, 로그인, 회원가입은 토큰이 아예 필요 없는 프리패스 구역
                        .requestMatchers("/api/auth/email/**").permitAll()
                        .requestMatchers("/api/auth/signin").permitAll()
                        .requestMatchers("/api/auth/signup").permitAll()

                        // 🔴 그 외의 모든 요청(예: 로그아웃 등)은 유효한 JWT 토큰이 필수로 있어야 함
                        .anyRequest().authenticated()
                )

                // 4. 원래 시큐리티가 제공하는 기본 인증 필터가 동작하기 바로 직전에,
                // 우리가 만든 JwtAuthenticationFilter를 먼저 태워서 검문하도록 순서 세팅
                .addFilterBefore(new JwtAuthenticationFilter(jwtTokenProvider),
                        UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}